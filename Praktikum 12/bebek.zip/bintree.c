#include <stdio.h>
#include <stdlib.h>
#include "bintree.h"
#include "boolean.h"

typedef Address BinTree;

BinTree NewTree (ElType root, BinTree left_tree, BinTree right_tree) {
    Address rootNode = (Address) malloc (sizeof(TreeNode));
    if (rootNode != NULL) {
        ROOT(rootNode) = root;
        LEFT(rootNode) = left_tree;
        RIGHT(rootNode) = right_tree;
    }
    return rootNode;
}

void CreateTree (ElType root, BinTree left_tree, BinTree right_tree, BinTree *p) {
    *p = NewTree(root, left_tree, right_tree);
}

Address newTreeNode(ElType val) {
    Address node = (Address) malloc (sizeof(TreeNode));
    if (node != NULL) {
        ROOT(node) = val;
        RIGHT(node) = NULL;
        LEFT(node) = NULL;
    }
    return node;
}

void deallocTreeNode (Address p) {
    free(p);
}

boolean isTreeEmpty (BinTree p) {
    return (p == NULL);
}

boolean isOneElmt (BinTree p) {
    return(!isTreeEmpty(p) && (RIGHT(p) == NULL) && (LEFT(p) == NULL));
}

boolean isUnerLeft (BinTree p) {
    return(!isTreeEmpty(p) && (LEFT(p) != NULL) && (RIGHT(p) == NULL));
}

boolean isUnerRight (BinTree p) {
    return(!isTreeEmpty(p) && (LEFT(p) == NULL) && (RIGHT(p) != NULL));
}

boolean isBinary (BinTree p) {
    return (!isTreeEmpty(p) && (LEFT(p) != NULL) && (RIGHT(p) != NULL));
}

void printPreorder(BinTree p) {
    printf("(");
    if (p != NULL) {
        printf("%d", ROOT(p));
        printPreorder(LEFT(p));
        printPreorder(RIGHT(p));
    }
    printf(")");
}

void printInorder(BinTree p) {
    printf("(");
    if (p != NULL) {
        printInorder(LEFT(p));
        printf("%d", ROOT(p));
        printInorder(RIGHT(p));
    }
    printf(")");   
}

void printPostorder(BinTree p) {
    printf("(");
    if (p != NULL) {
        printPostorder(LEFT(p));
        printPostorder(RIGHT(p));
        printf("%d", ROOT(p));
    }
    printf(")");
}

void printTreeR(BinTree p, int curr, int add) {
    if (p != NULL) {
        int i;
        for (i = 0; i < curr; i++) {
            printf(" ");
        }
        printf("%d\n", ROOT(p));

        printTreeR(LEFT(p), curr + add, add);
        printTreeR(RIGHT(p), curr + add, add);
    }
}

void printTree(BinTree p, int h) {
    printTreeR(p, 0, h);
}

int hitungBebek(BinTree root, int n) {
    int res = 0;
    hitungBebekRekursif(root, &res, 1, 0, n);

    return res;
}

void hitungBebekRekursif(BinTree root, int* res, int prodPath, int sumPath, int n) {
    if (isTreeEmpty(root)) return;
    sumPath += ROOT(root);
    prodPath *= (ROOT(root) % 10000);

    if (isOneElmt(root) && (sumPath == n)) 
        *res += (prodPath % 10000);

    if (LEFT(root) != NULL) 
        hitungBebekRekursif(LEFT(root), res, prodPath, sumPath, n);
    if (RIGHT(root) != NULL) 
        hitungBebekRekursif(RIGHT(root), res, prodPath, sumPath, n);
}
